-- Create the database if it doesn't already exist
CREATE DATABASE IF NOT EXISTS `quackers_db`;

-- Use the newly created database
USE `quackers_db`;

-- Create the 'articles' table
-- This table will store the information for Detective Quackers' case files.
CREATE TABLE IF NOT EXISTS `articles` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `title` VARCHAR(255) NOT NULL,
    `summary` TEXT NOT NULL,
    `full_story` LONGTEXT NOT NULL,
    `publish_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `active` BOOLEAN DEFAULT TRUE NOT NULL -- New column: TRUE for active, FALSE for inactive
);

-- Insert sample data into the 'articles' table
-- These are the articles that your PHP script will fetch.
-- Approximately half of the articles will now be set to 'inactive'.
INSERT INTO `articles` (`title`, `summary`, `full_story`, `active`) VALUES
('The Case of the Missing Crumb',
 'In a perplexing case that baffled many, three digestive biscuits vanished from the mantelpiece without a trace. Detective Quackers, with his astute observations, quickly deduced the culprit was an inside job.',
 'The meticulous tear on the wrapper, the utter lack of crumbs, and the repeated target led Quackers to a surprising conclusion: a plump, arrogant-looking squirrel, perched innocently on the birdbath with a half-eaten biscuit. The squirrel\'s sharp incisors, tidy eating habits, and easy access from the nearby oak tree were all the clues the master detective needed to crack the case. A true testament to Quackers\' ability to solve even the smallest of mysteries!', TRUE),

('The Purloined Pecan',
 'A daring theft from a bird feeder led Detective Quackers on a high-flying chase, uncovering a complex network of avian accomplices.',
 'The purloined pecan, a prized possession of local blue jays, was found missing from its usual perch. Quackers, after a thorough investigation of feather patterns and nut shell fragments, traced the theft to a notorious magpie syndicate operating in the eastern sector of the park. Justice, as always, was served.', TRUE),

('The Case of the Crooked Carrot',
 'Unraveling a garden sabotage, Quackers faced a verdant villain with a penchant for root vegetables.',
 'Mrs. Higgins\' prize-winning carrots were systematically being nibbled at their roots. Quackers, employing his unique blend of soil analysis and burrow tracking, identified a cunning rabbit as the perpetrator. The rabbit, known as "Buster," was apprehended and given a stern lecture on property rights.', TRUE),

('The Riddle of the Runaway Rubber Duck',
 'A puzzling disappearance from the pond led Quackers into the murky depths of a child\'s toy box.',
 'Little Timmy\'s favorite rubber duck, "Squeaky," vanished from the pond. Quackers, after interviewing several tadpoles and examining the current\'s flow, discovered Squeaky had been inadvertently scooped up by a passing fishing net and deposited in a nearby toy box, awaiting his next bath time adventure.', FALSE), -- Set to INACTIVE

('The Mystery of the Muffled Meow',
 'A series of unexplained muffled meows from a quiet alleyway drew Quackers into a tangled feline affair.',
 'The peculiar sounds led Quackers to a complex case involving a lost kitten, a grumpy tomcat, and an unexpected blanket fort. Through careful listening and observation of paw prints, Quackers reunited the kitten with its owner and mediated a truce between the alley cats.', TRUE),

('The Affair of the Absent Acorn',
 'When the community\'s prize acorn went missing from the annual Squirrel Fair, Quackers was on the case, facing a nut-orious thief.',
 'The disappearance of the Golden Acorn, a symbol of autumnal abundance, caused widespread panic. Quackers, examining the faint scent of pine sap and tiny claw marks, quickly identified a mischievous chipmunk with a penchant for shiny objects. The acorn was recovered, and the chipmunk was given a community service sentence of planting new oak trees.', FALSE), -- Set to INACTIVE

('The Scandal of the Soggy Seed',
 'A peculiar case of waterlogged birdseed threatened the local aviary, prompting Quackers to investigate a watery conspiracy.',
 'The bird feeder\'s contents were inexplicably damp, leading to soggy seeds and discontented birds. Quackers, observing the erratic flight patterns of a rogue pigeon and the tell-tale drip marks, uncovered a leaky garden hose aimed directly at the feeder. The hose was repaired, and the birds rejoiced.', TRUE),

('The Enigma of the Empty Eggshell',
 'A pristine eggshell, found mysteriously empty and intact, presented a baffling puzzle for the feathered detective.',
 'The perfectly hollowed eggshell, devoid of its contents, was a true anomaly. Quackers, after careful analysis of microscopic teeth marks and the faint scent of berries, deduced that a clever field mouse had meticulously extracted the yolk and albumen through a tiny, almost invisible hole, leaving the shell as a perplexing calling card.', FALSE), -- Set to INACTIVE

('The Case of the Curious Caterpillar',
 'A sudden surge in missing leaves from Farmer McGregor\'s prize cabbage patch led Quackers to an unexpected culprit.',
 'The vanishing foliage stumped Farmer McGregor. Quackers, with his keen eye for minute munching patterns and the subtle shimmer of silk, discovered a particularly ambitious caterpillar orchestrating a silent, leafy feast. The caterpillar was safely relocated to a less valuable patch of weeds.', TRUE),

('The Peril of the Pilfered Picnic',
 'A family picnic vanished without a trace from Willow Creek Park, and Quackers was called to recover the feast.',
 'The scene of the crime showed no signs of struggle, only the faint aroma of strawberry jam. Quackers, following a trail of sticky paw prints and discarded sandwich crusts, tracked the culprits to a family of industrious ants who had orchestrated a highly organized, albeit unauthorized, food transfer operation.', FALSE), -- Set to INACTIVE

('The Riddle of the Rustling Reeds',
 'Strange sounds emanating from the marsh at dusk indicated a hidden secret, challenging Quackers\' nocturnal investigative skills.',
 'The persistent rustling puzzled the local wildlife. Quackers, using his acute hearing and knowledge of marshland inhabitants, discovered a family of playful otters using the reeds as a slide, creating the mysterious sounds. The secret was harmless, but the otters were advised to be more discreet.', TRUE),

('The Affair of the Abandoned Apple',
 'A perfectly ripe apple, left uneaten beneath the orchard tree, hinted at a deeper, more emotional mystery.',
 'The untouched apple was unusual. Quackers, sensing a story beyond simple theft, interviewed the orchard\'s residents. He uncovered a tale of a young squirrel who had lost his favorite climbing branch and was too distraught to enjoy his treat. Quackers helped him find a new, even better branch, and the apple was finally enjoyed.', FALSE), -- Set to INACTIVE

('The Case of the Cunning Crow',
 'A series of shiny object disappearances from various gardens pointed to a highly intelligent, feathered suspect.',
 'Jewelry, bottle caps, and even a small spoon vanished from front yards. Quackers, observing the flight paths of local corvids and the glint of sunlight on hidden stashes, identified a particularly cunning crow with a passion for collecting. The crow\'s hoard was discovered, and a small, shiny tribute was left in exchange for the return of the stolen items.', TRUE),

('The Mystery of the Muddy Paw Prints',
 'Unexplained muddy tracks leading into the pristine library suggested a breach of decorum and a peculiar intruder.',
 'The librarian was distraught by the muddy mess. Quackers, analyzing the unique print pattern and the distinct scent of damp earth, traced the tracks to a curious badger who had merely sought refuge from a sudden downpour, leaving behind an unintentional, but solvable, mystery.', FALSE); -- Set to INACTIVE
