<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detective Quackers: Master of Deduction</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Custom CSS -->
    <link rel="stylesheet" href="style.css">
    <style>
        /* Inter font for better readability */
        body {
            font-family: 'Inter', sans-serif;
        }
        /* Custom styles for the slider */
        .slider-container {
            position: relative;
            max-width: 800px; /* Adjust as needed */
            margin: auto;
            overflow: hidden;
            border-radius: 0.75rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .slider-wrapper {
            display: flex;
            transition: transform 0.5s ease-in-out;
        }
        .slider-slide {
            min-width: 100%;
            flex-shrink: 0;
        }
        .slider-slide img {
            width: 100%;
            height: auto;
            display: block;
            border-radius: 0.75rem; /* Match container border-radius */
        }
        .slider-nav-btn {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background-color: rgba(0, 0, 0, 0.5);
            color: white;
            border: none;
            padding: 1rem 0.75rem;
            cursor: pointer;
            font-size: 1.5rem;
            border-radius: 0.5rem;
            transition: background-color 0.3s ease;
            z-index: 10;
        }
        .slider-nav-btn:hover {
            background-color: rgba(0, 0, 0, 0.7);
        }
        .prev-btn {
            left: 10px;
        }
        .next-btn {
            right: 10px;
        }
        .dot-container {
            text-align: center;
            padding: 10px 0;
        }
        .dot {
            height: 15px;
            width: 15px;
            margin: 0 5px;
            background-color: #bbb;
            border-radius: 50%;
            display: inline-block;
            transition: background-color 0.6s ease;
            cursor: pointer;
        }
        .dot.active {
            background-color: #717171;
        }
    </style>
</head>
<body class="bg-gray-100 text-gray-800 antialiased">

    <div class="container mx-auto p-4 md:p-8">
        <!-- Header Section -->
        <header class="text-center mb-10 bg-white p-6 rounded-lg shadow-lg">
            <img id="myImage" src="detectivequack3.jpg" alt="Detective Quackers" class="mx-auto rounded-full w-48 h-48 object-cover border-4 border-yellow-500 shadow-md mb-4" onerror="this.onerror=null;this.src='https://placehold.co/192x192/FFD700/000000?text=Quackers';">
            <img id="myFlag" src=".flag.jpg" alt="A clickable image">
            <h1 class="text-5xl font-extrabold text-yellow-700 mb-2">Detective Quackers</h1>
            <p class="text-xl text-gray-600 italic">"No crumb too small, no mystery too grand."</p>
        </header>

        <!-- Main Content Area -->
        <main class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- About Section -->
            <section class="lg:col-span-2 bg-white p-6 rounded-lg shadow-lg">
                <h2 class="text-3xl font-bold text-yellow-600 mb-4 border-b-2 border-yellow-300 pb-2">About the Master Detective</h2>
                <p class="text-lg leading-relaxed mb-4">
                    Detective Quackers, renowned for his unparalleled deductive reasoning and keen eye for detail, operates from his humble abode at 221B Pondside. With the loyal Dr. Waddle by his side, Quackers has solved countless perplexing cases, from the most trivial of missing items to the most intricate of fowl play. His methods, though unconventional, are always effective, leaving no stone (or pebble) unturned.
                </p>
                <p class="text-lg leading-relaxed">
                    A true connoisseur of fine biscuits and a formidable opponent to any criminal mind, Quackers embodies the spirit of classic detective work with a unique, feathered flair.
                </p>
            </section>

            <!-- Latest Case Summary (Dynamically pulled from 'database') -->
            <aside class="bg-white p-6 rounded-lg shadow-lg">
                <?php
                // --- Simulate Database Articles ---
                // In a real application, you would connect to a database (e.g., MySQL, PostgreSQL)
                // and fetch this data using SQL queries (e.g., PDO or mysqli).
                // Example: $conn = new PDO("mysql:host=localhost;dbname=quackers_db", "user", "password");
                // $stmt = $conn->query("SELECT title, summary, full_story FROM articles ORDER BY publish_date DESC LIMIT 1");
                // $latestArticle = $stmt->fetch(PDO::FETCH_ASSOC);

                $articles = [
                    [
                        'id' => 1,
                        'title' => 'The Case of the Missing Crumb',
                        'summary' => 'In a perplexing case that baffled many, three digestive biscuits vanished from the mantelpiece without a trace. Detective Quackers, with his astute observations, quickly deduced the culprit was an inside job.',
                        'full_story' => 'The meticulous tear on the wrapper, the utter lack of crumbs, and the repeated target led Quackers to a surprising conclusion: a plump, arrogant-looking squirrel, perched innocently on the birdbath with a half-eaten biscuit. The squirrel\'s sharp incisors, tidy eating habits, and easy access from the nearby oak tree were all the clues the master detective needed to crack the case. A true testament to Quackers\' ability to solve even the smallest of mysteries!'
                    ],
                    [
                        'id' => 2,
                        'title' => 'The Purloined Pecan',
                        'summary' => 'A daring theft from a bird feeder led Detective Quackers on a high-flying chase, uncovering a complex network of avian accomplices.',
                        'full_story' => 'The purloined pecan, a prized possession of local blue jays, was found missing from its usual perch. Quackers, after a thorough investigation of feather patterns and nut shell fragments, traced the theft to a notorious magpie syndicate operating in the eastern sector of the park. Justice, as always, was served.'
                    ],
                    [
                        'id' => 3,
                        'title' => 'The Case of the Crooked Carrot',
                        'summary' => 'Unraveling a garden sabotage, Quackers faced a verdant villain with a penchant for root vegetables.',
                        'full_story' => 'Mrs. Higgins\' prize-winning carrots were systematically being nibbled at their roots. Quackers, employing his unique blend of soil analysis and burrow tracking, identified a cunning rabbit as the perpetrator. The rabbit, known as "Buster," was apprehended and given a stern lecture on property rights.'
                    ],
                    [
                        'id' => 4,
                        'title' => 'The Riddle of the Runaway Rubber Duck',
                        'summary' => 'A puzzling disappearance from the pond led Quackers into the murky depths of a child\'s toy box.',
                        'full_story' => 'Little Timmy\'s favorite rubber duck, "Squeaky," vanished from the pond. Quackers, after interviewing several tadpoles and examining the current\'s flow, discovered Squeaky had been inadvertently scooped up by a passing fishing net and deposited in a nearby toy box, awaiting his next bath time adventure.'
                    ]
                ];

                $latestArticle = $articles[0]; // Get the first (latest) article for this section
                ?>

                <h2 class="text-3xl font-bold text-yellow-600 mb-4 border-b-2 border-yellow-300 pb-2">Latest Exploit: <?php echo htmlspecialchars($latestArticle['title']); ?></h2>
                <p class="text-lg leading-relaxed mb-4">
                    <?php echo htmlspecialchars($latestArticle['summary']); ?>
                </p>
                <button id="readMoreBtn" class="bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-2 px-4 rounded-full shadow-md transition duration-300 ease-in-out">
                    Read Full Story
                </button>
                <div id="fullStory" class="hidden mt-4 text-lg leading-relaxed">
                    <p>
                        <?php echo htmlspecialchars($latestArticle['full_story']); ?>
                    </p>
                </div>
            </aside>
        </main>

        <!-- Search Feature Section -->
        <section class="mt-10 bg-white p-6 rounded-lg shadow-lg">
            <h2 class="text-3xl font-bold text-yellow-600 mb-6 text-center border-b-2 border-yellow-300 pb-2">Search Case Files</h2>
            <form action="index.php" method="GET" class="flex flex-col sm:flex-row items-center justify-center gap-4 mb-6">
                <input type="text" name="search_query" placeholder="Search by title or keyword..."
                       class="w-full sm:w-2/3 p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500"
                       value="<?php echo htmlspecialchars($_GET['search_query'] ?? ''); ?>">
                <button type="submit" class="w-full sm:w-1/3 bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-3 px-6 rounded-lg shadow-md transition duration-300 ease-in-out">
                    Search
                </button>
            </form>

            <div id="searchResults" class="mt-8">
                <?php
                $searchQuery = $_GET['search_query'] ?? '';
                $searchResults = [];

                if (!empty($searchQuery)) {
                    $searchQueryLower = strtolower($searchQuery);
                    foreach ($articles as $article) {
                        if (str_contains(strtolower($article['title']), $searchQueryLower) ||
                            str_contains(strtolower($article['summary']), $searchQueryLower) ||
                            str_contains(strtolower($article['full_story']), $searchQueryLower)) {
                            $searchResults[] = $article;
                        }
                    }
                }

                if (!empty($searchQuery) && empty($searchResults)) {
                    echo '<p class="text-center text-gray-600 text-lg">No articles found matching your search for "<strong>' . htmlspecialchars($searchQuery) . '</strong>".</p>';
                } elseif (!empty($searchResults)) {
                    echo '<h3 class="text-2xl font-semibold text-yellow-700 mb-4">Search Results for "'. htmlspecialchars($searchQuery) .'"</h3>';
                    echo '<div class="grid grid-cols-1 md:grid-cols-2 gap-6">';
                    foreach ($searchResults as $result) {
                        echo '<div class="bg-gray-50 p-4 rounded-lg shadow-md">';
                        echo '<h4 class="font-bold text-xl text-yellow-800 mb-2">' . htmlspecialchars($result['title']) . '</h4>';
                        echo '<p class="text-gray-700">' . htmlspecialchars($result['summary']) . '</p>';
                        // You could add a "Read More" button here that links to a detailed article page
                        echo '</div>';
                    }
                    echo '</div>';
                }
                ?>
            </div>
        </section>

        <!-- Image Slider Section -->
        <section class="mt-10 bg-white p-6 rounded-lg shadow-lg">
            <h2 class="text-3xl font-bold text-yellow-600 mb-6 text-center border-b-2 border-yellow-300 pb-2">Quackers in Action!</h2>
            <div class="slider-container">
                <div class="slider-wrapper" id="sliderWrapper">
                    <div class="slider-slide">
                        <img src="https://placehold.co/800x450/FDBA74/654321?text=Quackers+on+the+Case+1" alt="Detective Quackers investigating a clue.">
                    </div>
                    <div class="slider-slide">
                        <img src="https://placehold.co/800x450/FDBA74/654321?text=Quackers+on+the+Case+2" alt="Detective Quackers interrogating a suspect.">
                    </div>
                    <div class="slider-slide">
                        <img src="https://placehold.co/800x450/FDBA74/654321?text=Quackers+on+the+Case+3" alt="Detective Quackers making a grand revelation.">
                    </div>
                </div>
                <button class="slider-nav-btn prev-btn" id="prevBtn">&#10094;</button>
                <button class="slider-nav-btn next-btn" id="nextBtn">&#10095;</button>
            </div>
            <div class="dot-container" id="dotContainer">
                <span class="dot active" data-slide-index="0"></span>
                <span class="dot" data-slide-index="1"></span>
                <span class="dot" data-slide-index="2"></span>
            </div>
        </section>

        <!-- Footer Section -->
        <footer class="text-center mt-10 p-6 bg-white rounded-lg shadow-lg text-gray-600">
            <p>&copy; 2025 Detective Quackers & Dr. Waddle. All rights reserved.</p>
            <p class="text-sm mt-2">Inspired by the greatest minds, feathered and otherwise.</p>
        </footer>
    </div>

    <!-- Custom JavaScript -->
    <script src="script.js"></script>
</body>
</html>
