document.addEventListener('DOMContentLoaded', () => {
    // --- Read More Button Logic ---
    const readMoreBtn = document.getElementById('readMoreBtn');
    const fullStoryDiv = document.getElementById('fullStory');

    if (readMoreBtn && fullStoryDiv) {
        readMoreBtn.addEventListener('click', () => {
            fullStoryDiv.classList.toggle('hidden');
            if (fullStoryDiv.classList.contains('hidden')) {
                readMoreBtn.textContent = 'Read Full Story';
            } else {
                readMoreBtn.textContent = 'Show Less';
            }
        });
    } else {
        // Log a warning if elements are not found, helpful for debugging
        console.warn("Read more button or full story div not found. This might be expected if the element IDs are different or the elements are not present.");
    }

    // --- Image Slider Logic ---
    const sliderWrapper = document.getElementById('sliderWrapper');
    const slides = document.querySelectorAll('.slider-slide');
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    const dotContainer = document.getElementById('dotContainer');
    const dots = document.querySelectorAll('.dot');

    // Log all slider elements to the console to verify they are found
    console.log('Slider elements found:');
    console.log('sliderWrapper:', sliderWrapper);
    console.log('slides:', slides, 'length:', slides.length);
    console.log('prevBtn:', prevBtn);
    console.log('nextBtn:', nextBtn);
    console.log('dotContainer:', dotContainer);
    console.log('dots:', dots, 'length:', dots.length);

    // If any essential slider element is missing, log an error and stop execution
    if (!sliderWrapper || slides.length === 0 || !prevBtn || !nextBtn || !dotContainer || dots.length === 0) {
        console.error("One or more essential slider elements were not found. Slider functionality will not work.");
        return; // Exit the function if elements are missing
    }

    let currentSlide = 0;
    const totalSlides = slides.length;

    // Function to show a specific slide
    function showSlide(index) {
        console.log('Calling showSlide with index:', index); // Log the index being set
        // Ensure index wraps around for continuous sliding
        if (index >= totalSlides) {
            currentSlide = 0;
        } else if (index < 0) {
            currentSlide = totalSlides - 1;
        } else {
            currentSlide = index;
        }

        // Calculate the transform value to move the slider wrapper
        const transformValue = `translateX(${-currentSlide * 100}%)`;
        console.log('Setting transform to:', transformValue); // Log the applied transform
        sliderWrapper.style.transform = transformValue;

        // Update active dot indicator
        dots.forEach((dot, i) => {
            if (i === currentSlide) {
                dot.classList.add('active');
            } else {
                dot.classList.remove('active');
            }
        });
    }

    // Event listener for the previous button
    prevBtn.addEventListener('click', () => {
        showSlide(currentSlide - 1);
    });

    // Event listener for the next button
    nextBtn.addEventListener('click', () => {
        showSlide(currentSlide + 1);
    });

    // Event listeners for the navigation dots
    dotContainer.addEventListener('click', (event) => {
        if (event.target.classList.contains('dot')) {
            const slideIndex = parseInt(event.target.dataset.slideIndex);
            showSlide(slideIndex);
        }
    });

    // Auto-play functionality
    let autoPlayInterval;
    function startAutoPlay() {
        stopAutoPlay(); // Clear any existing interval before starting a new one
        autoPlayInterval = setInterval(() => {
            showSlide(currentSlide + 1);
        }, 5000); // Change slide every 5 seconds
    }

    function stopAutoPlay() {
        clearInterval(autoPlayInterval);
    }

    // Pause auto-play when the mouse enters the slider area
    const sliderContainer = document.querySelector('.slider-container');
    if (sliderContainer) {
        sliderContainer.addEventListener('mouseenter', stopAutoPlay);
        sliderContainer.addEventListener('mouseleave', startAutoPlay);
    }

    // Initialize the slider to show the first slide and start auto-play
    showSlide(0);
    startAutoPlay();
});

// Get the image element by its ID
const image = document.getElementById('myImage');

// Define the speed and direction of the movement
const moveSpeed = 5; // Pixels per interval
let currentPosition = 50; // Starting position (matches the CSS)
let animationId = null; // A variable to hold the interval ID

// Function to move the image
function moveImage() {
    currentPosition += moveSpeed;
    image.style.left = currentPosition + 'px';

    // Optional: Stop the animation after a certain distance
    // This is a simple example. You can make it stop at the edge of the screen.
    if (currentPosition > window.innerWidth - image.width) {
        clearInterval(animationId);
        animationId = null; // Reset the ID
    }
}

// Function to start the animation when the image is clicked
function startAnimation() {
    // Only start the animation if it's not already running
    if (animationId === null) {
        // Set an interval to call the `moveImage` function repeatedly
        animationId = setInterval(moveImage, 20); // The '20' is in milliseconds. A smaller number makes it faster/smoother.
    }
}

// Add a click event listener to the image
image.addEventListener('click', startAnimation);
